Steps to run the code:
--------------------------
1. install nodeJS, if not isntalled. 
2. if already installed, copy the files index.js and package.json in the local machine(in a new folder).
3. open the command line from the same folder, the newly created local folder (or run git bash from the same folder)
4. Run the command, npm install.
5. Run the command, npm start 
Here you see your output for the problem (also look at output.jpg)

  --sorted users with user id within 100km of dublin office--

User ID: 4, Name: Ian Kehoe , Distance from dublin office : 10.566936288868758km

User ID: 5, Name: Nora Dempsey , Distance from dublin office : 23.287320663099482km

User ID: 6, Name: Theresa Enright , Distance from dublin office : 24.085360019144122km

User ID: 8, Name: Eoin Ahearn , Distance from dublin office : 83.5325311678587km

User ID: 11, Name: Richard Finnegan , Distance from dublin office : 38.137568098201655km

User ID: 12, Name: Christina McArdle , Distance from dublin office : 41.7687255008362km

User ID: 13, Name: Olive Ahearn , Distance from dublin office : 62.23170226292825km

User ID: 15, Name: Michael Ahearn , Distance from dublin office : 43.72248745925171km

User ID: 17, Name: Patricia Cahill , Distance from dublin office : 96.07859923633524km

User ID: 23, Name: Eoin Gallagher , Distance from dublin office : 82.6949261163998km

User ID: 24, Name: Rose Enright , Distance from dublin office : 89.03103382223571km

User ID: 26, Name: Stephen McArdle , Distance from dublin office : 98.87459926458503km

User ID: 29, Name: Oliver Ahearn , Distance from dublin office : 72.20178549704268km

User ID: 30, Name: Nick Enright , Distance from dublin office : 82.64284999110231km

User ID: 31, Name: Alan Behan , Distance from dublin office : 44.29082235506625km

User ID: 39, Name: Lisa Ahearn , Distance from dublin office : 38.35801477480562km